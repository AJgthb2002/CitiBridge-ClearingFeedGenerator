package com.citi.FeedGenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedGeneratorApplication.class, args);
	}

}
