package com.citi.FeedGenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
